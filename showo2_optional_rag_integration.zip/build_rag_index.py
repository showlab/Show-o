"""Run from the extracted integration package or from a Show-o repository root."""
import argparse
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--rag-dir', default='show-o2/investigative_rag')
p.add_argument('--model', default='sentence-transformers/all-MiniLM-L6-v2')
args = p.parse_args()
root = Path(args.rag_dir).resolve()
import sys
sys.path.insert(0, str(root))
from retrieval import build_index
print(build_index(root, model_name=args.model))
