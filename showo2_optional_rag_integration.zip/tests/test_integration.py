import sys
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / 'show-o2'))
from apply_integration import patch
from investigative_rag.inference_support import final_prompt, retrieve_context
from investigative_rag.retrieval import load_rows


class TestRAG(unittest.TestCase):
    def test_entries(self):
        root = BASE / 'show-o2' / 'investigative_rag'
        rows = load_rows(root)
        self.assertEqual(len(rows), 12)
        self.assertEqual(len({r['id'] for r in rows}), 12)
        self.assertEqual(len([r for r in rows if r['evidence_status'] == 'analyst_extrapolation_review_needed']), 3)

    def test_prompt(self):
        p = 'Analyze the image.'
        self.assertEqual(final_prompt(p, ''), p)
        out = final_prompt(p, 'Some reference information')
        self.assertTrue(out.startswith(p))
        self.assertIn('not evidence', out)
        self.assertIn('<reference_knowledge>', out)

    def test_patcher_is_idempotent(self):
        self.assertEqual(patch('RAG_INTEGRATION_V1'), 'RAG_INTEGRATION_V1')

    def test_patcher_refuses_different_versions(self):
        with self.assertRaises(RuntimeError):
            patch('unrelated script')


if __name__ == '__main__':
    unittest.main()
