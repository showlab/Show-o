# Show-o2 + Qwen3-VL optional investigative RAG integration

This package applies a **local, fail-closed patch** to the existing
`show-o2/inference_qwen3_showo2_deepstack.py`. It does **not** modify your remote GitHub repository.

## Install

From the extracted package directory (after cloning your Show-o repository):

```bash
python apply_integration.py /path/to/Show-o
cp build_rag_index.py /path/to/Show-o/build_rag_index.py
cd /path/to/Show-o
python -m pip install -r /path/to/extracted/package/requirements-rag.txt
python build_rag_index.py --rag-dir show-o2/investigative_rag
```

The index builder downloads `sentence-transformers/all-MiniLM-L6-v2` once if the weights are not cached. The `knowledge.faiss` and manifest are generated locally.

## Inference (run from show-o2 directory)

```bash
# Original execution unchanged (RAG off by default)
python inference_qwen3_showo2_deepstack.py --image /path/to/photo.jpg --stage stage2

# Enable investigative RAG; preserve your original prompt file and all stages/alphas
python inference_qwen3_showo2_deepstack.py --image /path/to/photo.jpg --stage stage2 --use-rag
```

Options: `--rag-dir`, `--rag-top-k` (default 5), `--rag-min-score` (default None), `--rag-observation-max-tokens` (default 180). The script saves neutral observations and retrieved record metadata in each alpha result. `run_identity` hashes the corpus/index/source provenance and RAG settings, keeping the run cache independent.

## Behavior

RAG off: existing single-pass image+prompt generation. No Sentence Transformers / FAISS import.

RAG on, for each alpha and stage: generate neutral image observations using the same patched final+DeepStack features, semantic-search the curated knowledge base, then generate the final response from the **original image + original prompt + retrieved reference context**.

The reference content is untrusted background, not evidence of actual wrongdoing. 3 analyst-review-needed entries are suppressed from default search. RAG supplies risks of potential *misuse of stolen photos*, not criminal-intent judgments about individuals pictured.

## Verification and limitations

- `python -m unittest discover -s tests -v` validates data, prompt behavior and patcher guards.
- The script patch is verified with Python `ast.parse` before being written; a `.py.before_rag_backup` is made.
- Full GPU inference and learned index generation require your own environment, weights and a network connection to download the embedding model. They were **not run** here.
- With a single explicit `--output results.json` path, runs will still target that explicit file, matching existing behavior; use an output directory for comparison experiments.
- This corpus contains 12 reference-linked **editorially summarized** entries (not verbatim MITRE facts). All require domain expert review. Scores are similarity scores, not probabilities of criminal activity.
- Photograph-only scope: no document OCR, provenance, metadata or authenticity analysis.
