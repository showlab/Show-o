"""Idempotent, fail-closed patch of the existing V2 Show-o2 inference file.

Usage from extracted package root:
    python apply_integration.py /path/to/Show-o
Copies the new module and modifies only show-o2/inference_qwen3_showo2_deepstack.py.
"""
import argparse
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent


def replace_once(text, old, new):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'Expected exactly one match, found {count}: {old[:100]!r}')
    return text.replace(old, new, 1)


def patch(script):
    if 'RAG_INTEGRATION_V1' in script:
        return script
    script = replace_once(script, 'from qwen3_showo2_deepstack import (', '''# RAG_INTEGRATION_V1: retrieval is imported lazily only when enabled.
from investigative_rag.inference_support import OBSERVATION_PROMPT, final_prompt

from qwen3_showo2_deepstack import (''')
    script = replace_once(script, 'OVERWRITE_EXISTING = False\nSEED = 42', '''OVERWRITE_EXISTING = False
USE_RAG = False
RAG_TOP_K = 5
RAG_MIN_SCORE = None  # Do not use an uncalibrated similarity cutoff.
RAG_DIR = SCRIPT_DIR / "investigative_rag"
RAG_OBSERVATION_MAX_TOKENS = 180
SEED = 42''')
    script = replace_once(script, 'def process_image(image_path, jobs, checkpoints, args):', '''def process_image(image_path, jobs, checkpoints, args):''')
    script = replace_once(script, '''        for alpha in args.alphas:
            reset_seed()

            # The same alpha applies to final and intermediate features.''', '''        for alpha in args.alphas:
            reset_seed()

            # The same alpha applies to final and intermediate features.''')
    old = '''            with patched_image_features(qwen, final, fused_deep):
                ids = qwen.generate(
                    **inputs,
                    max_new_tokens=args.max_new_tokens,
                    do_sample=False,
                    use_cache=True,
                )

            generated = ids[:, inputs["input_ids"].shape[1]:]'''
    new = '''            rag_observation = None
            retrieved_knowledge = []
            effective_inputs = inputs
            effective_prompt = job["prompt"]

            if args.use_rag:
                # Two-pass mode: obtain *neutral* observations before retrieval.
                observation_inputs = move_inputs_to_device(
                    prepare_qwen_inputs(processor, image, OBSERVATION_PROMPT),
                    base.DEVICE,
                )
                reset_seed()
                with patched_image_features(qwen, final, fused_deep):
                    observation_ids = qwen.generate(
                        **observation_inputs,
                        max_new_tokens=args.rag_observation_max_tokens,
                        do_sample=False,
                        use_cache=True,
                    )
                rag_observation = processor.batch_decode(
                    observation_ids[:, observation_inputs["input_ids"].shape[1]:],
                    skip_special_tokens=True,
                    clean_up_tokenization_spaces=False,
                )[0]

                from investigative_rag.inference_support import retrieve_context
                context, retrieved_knowledge = retrieve_context(
                    args.rag_retriever, rag_observation,
                    top_k=args.rag_top_k, min_score=args.rag_min_score,
                )
                effective_prompt = final_prompt(job["prompt"], context)
                effective_inputs = move_inputs_to_device(
                    prepare_qwen_inputs(processor, image, effective_prompt),
                    base.DEVICE,
                )

            if args.use_rag:
                reset_seed()
            with patched_image_features(qwen, final, fused_deep):
                ids = qwen.generate(
                    **effective_inputs,
                    max_new_tokens=args.max_new_tokens,
                    do_sample=False,
                    use_cache=True,
                )

            generated = ids[:, effective_inputs["input_ids"].shape[1]:]'''
    script = replace_once(script, old, new)
    script = replace_once(script, '''                "output": text,
            })''', '''                "output": text,
                **({
                    "rag_enabled": True,
                    "rag_observation": rag_observation,
                    "retrieved_knowledge": retrieved_knowledge,
                    "rag_effective_prompt_sha256": hashlib.sha256(
                        effective_prompt.encode("utf-8")
                    ).hexdigest(),
                } if args.use_rag else {}),
            })''')
    script = replace_once(script, '''    parser.add_argument("--vae-path", default=base.WAN_VAE_PATH)''', '''    parser.add_argument("--vae-path", default=base.WAN_VAE_PATH)
    parser.add_argument("--use-rag", action="store_true", default=USE_RAG)
    parser.add_argument("--rag-dir", default=str(RAG_DIR))
    parser.add_argument("--rag-top-k", type=int, default=RAG_TOP_K)
    parser.add_argument("--rag-min-score", type=float, default=RAG_MIN_SCORE)
    parser.add_argument("--rag-observation-max-tokens", type=int,
                        default=RAG_OBSERVATION_MAX_TOKENS)''')
    script = replace_once(script, '''    args = parser.parse_args()

    if any(not 0 <= alpha <= 1 for alpha in args.alphas):''', '''    args = parser.parse_args()

    args.rag_retriever = None
    args.rag_provenance = None
    if args.use_rag:
        from investigative_rag.inference_support import initialize_rag
        args.rag_retriever, args.rag_provenance = initialize_rag(
            args.rag_dir, top_k=args.rag_top_k
        )
        if args.rag_observation_max_tokens < 1:
            parser.error("rag-observation-max-tokens must be positive")

    if any(not 0 <= alpha <= 1 for alpha in args.alphas):''')
    script = replace_once(script, '''        "max_new_tokens": args.max_new_tokens,
    }''', '''        "max_new_tokens": args.max_new_tokens,
        # RAG settings change the run identity only in RAG mode.
        **({"rag": args.rag_provenance,
            "rag_min_score": args.rag_min_score,
            "rag_observation_max_tokens": args.rag_observation_max_tokens,
            "rag_observation_prompt": OBSERVATION_PROMPT}
           if args.use_rag else {}),
    }''')
    script = replace_once(script, '''        run_identity=job["identity"],
    )''', '''        run_identity=job["identity"],
        **({"rag_enabled": True, "rag_provenance": job["identity"].get("rag")}
           if job["identity"].get("rag") else {}),
    )''')
    return script


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo', type=Path, help='Local cloned Show-o repository root')
    args = p.parse_args()
    dest = args.repo / 'show-o2'
    target = dest / 'inference_qwen3_showo2_deepstack.py'
    if not target.is_file():
        p.error(f'Cannot find {target}')
    original = target.read_text(encoding='utf-8')
    updated = patch(original)  # Verify ALL anchors before writing anything.
    import ast
    ast.parse(updated, filename=str(target))
    if updated == original:
        print('Already patched; no changes made to inference script.')
    else:
        backup = target.with_suffix('.py.before_rag_backup')
        if not backup.exists():
            backup.write_text(original, encoding='utf-8')
        target.write_text(updated, encoding='utf-8')
        print(f'Updated {target} (backup: {backup})')
    source = ROOT / 'show-o2' / 'investigative_rag'
    destination = dest / 'investigative_rag'
    shutil.copytree(source, destination, dirs_exist_ok=True)
    print(f'Copied {destination}')
    print('Build index: python build_rag_index.py --rag-dir show-o2/investigative_rag')


if __name__ == '__main__':
    main()
